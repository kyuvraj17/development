package com.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.demo.exception.DemoException;
import com.demo.exception.PersonNotFoundException;
import com.demo.model.ErrorMessage;

@RestControllerAdvice
public class DemoExceptionHandler {

	@ExceptionHandler(DemoException.class)
	public ResponseEntity<ErrorMessage> demoException(DemoException demoException) {

		ErrorMessage errorMessage = new ErrorMessage(demoException.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);

	}

	@ExceptionHandler(PersonNotFoundException.class)
	public ResponseEntity<ErrorMessage> personNotFoundException(PersonNotFoundException exception) {

		ErrorMessage errorMessage = new ErrorMessage(exception.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorMessage> exception(Exception exception) {

		ErrorMessage errorMessage = new ErrorMessage(exception.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);

	}
}
